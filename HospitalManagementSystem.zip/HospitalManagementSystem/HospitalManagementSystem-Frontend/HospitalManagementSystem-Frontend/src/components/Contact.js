import React from 'react'

const Contact = () => {
    return (
        <>
            <div className="container">
                <h2 className="py-3 text-center">Contact</h2>
                <h3>
                    Start working with us today to register as Doctor:
                </h3>
                <h4> 
                      subbareddymedapati60@gmail.com                     
                <ul style={{color : "red"}}>
                    <li>
                    <h1>Emailid:</h1><h4>admin@gmail.com</h4>
                    </li>
                    <li>
                    <h1>Password</h1><h4>admin</h4> 
                    </li>
                </ul>
            </h4>
                
                </div>
        </>
    )
}

export default Contact
